package com.yash.library.test;

public class Launchlibrary {
	public static void main(String[] args) {
		BookTest.launchFactory();
	}
}
