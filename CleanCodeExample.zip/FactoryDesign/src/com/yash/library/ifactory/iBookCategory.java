package com.yash.library.ifactory;

import com.yash.library.model.Book;

public interface iBookCategory {
	Book getBookNames(int id);
}
